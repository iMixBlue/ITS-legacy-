﻿using System.Runtime.CompilerServices;
using System.IO.Pipes;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
public class Queue : MonoBehaviour
{
    
    public float changeSpeed = 0.5f;
    public bool stopBool = true;
    public float duration = 3.0f;
    private GameObject npc;

    public static IEnumerator WaitForSeconds(float duration,Action action){
    
               yield return new WaitForSeconds(duration);
               action?.Invoke();
    }
    private void StopAndChangeStates(){
       npc.GetComponent<Animator>().SetBool("isWalk",true);
       npc.GetComponent<Enemy>().speed = changeSpeed;
       npc.GetComponent<Enemy>().setIsRun();
    }
     private void OnTriggerEnter(Collider other)
    {
        if(other.tag =="npc"){

            // UnityEngine.Debug.Log("11");
         npc = other.gameObject;
         if(stopBool ==false){
         npc.GetComponent<Enemy>().speed = changeSpeed;
         }
                   if(stopBool == true){
          npc.GetComponent<Enemy>().speed = 0;
        //   npc.GetComponent<Animator>().enabled = false;
        npc.GetComponent<Enemy>().setIsRun();
       npc.GetComponent<Animator>().SetBool("isWalk",false);
    //  UnityEngine.Debug.Log(npc.GetComponent<Animator>().GetBool("isWalk"));
       StartCoroutine(WaitForSeconds(duration,()=>{StopAndChangeStates();}));    
       } 
        }
    }
}
