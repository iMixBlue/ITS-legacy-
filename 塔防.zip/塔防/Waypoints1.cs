﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoints1 : MonoBehaviour {


    public static Transform[] positions1;

    void Awake()
    {
        positions1 = new Transform[transform.childCount];
        for (int i = 0; i < positions1.Length; i++)
        {
            positions1[i] = transform.GetChild(i);
        }
        
    }
}
