﻿using System.Security.AccessControl;
using System.Diagnostics;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;


public class Enemy : MonoBehaviour {

    public int WaysNum=1;
    private Animator animator;
    public float speed = 1f;
    private Transform[] positions1;
    private Transform[] positions2;
    private Transform[] positions3;
    private Transform[] positions4;
    private Transform[] positions5;
    private Transform[] positions6;
    private int index = 0;
    private bool isRun = false;

	void Start () {
        animator = GetComponent<Animator>();
        positions1 = Waypoints1.positions1;
        positions2= Waypoints2.positions2;
        positions3=Waypoints3.positions3;
        positions4=Waypoints4.positions4;
        positions5=Waypoints5.positions5;
        switch(WaysNum){
            case 1:
        transform.forward=positions1[index].position-transform.position;
        break;
        case 2:
        transform.forward=positions2[index].position-transform.position;
        break;
        case 3:
        transform.forward=positions3[index].position-transform.position;
        break;
        case 4:
        transform.forward=positions4[index].position-transform.position;
        break;
        case 5:
        transform.forward=positions5[index].position-transform.position;
        break;
        }
	}
	

	void Update () {

        if (Input.GetKeyDown(KeyCode.O)){
        isRun = true;
	}
    if(isRun){
        animator.SetBool("isWalk",true);
        Move();
    }
    }
     public void setIsRun(){
         isRun = !isRun;
     }

    void Move()
    {  
        if(WaysNum==1){
            if (index > positions1.Length - 1) return;
            if(Vector3.Distance(positions1[index].position,transform.position)<0.2f){
                if(index!=positions1.Length-1){
                 index++;
                }
                if(Vector3.Distance(positions1[index].position,transform.position)<0.2f){
                    // ReachDestination();
                    animator.SetBool("isWalk",false);
                    // UnityEngine.Debug.Log(animator);
                    isRun = false;
                }
              transform.forward=positions1[index].position-transform.position;
            }
                transform.Translate(Vector3.forward * speed * Time.deltaTime, Space.Self);
            
        }
        /*
            if(WaysNum==2){
               if (index > positions2.Length - 1) return;
            if(Vector3.Distance(positions2[index].position,transform.position)<0.2f){
                if(index!=positions2.Length-1){
                    index++;
                }
                if(Vector3.Distance(positions2[index].position,transform.position)<0.2f){
                    // ReachDestination();
                }
              transform.forward=positions2[index].position-transform.position;
            
            }
            transform.Translate(Vector3.forward*speed*Time.deltaTime,Space.Self);
            }
            if(WaysNum==3){
                if (index > positions3.Length - 1) return;
            if(Vector3.Distance(positions3[index].position,transform.position)<0.2f){
                if(index!=positions3.Length-1){
                    index++;
                }
                if(Vector3.Distance(positions3[index].position,transform.position)<0.2f){
                    // ReachDestination();
                }
              transform.forward=positions3[index].position-transform.position;
             
            }
            transform.Translate(Vector3.forward*speed*Time.deltaTime,Space.Self);
            }
            if(WaysNum==4){
                      if (index > positions4.Length - 1) return;
            if(Vector3.Distance(positions4[index].position,transform.position)<0.2f){
                if(index!=positions4.Length-1){
                    index++;
                }
                if(Vector3.Distance(positions4[index].position,transform.position)<0.2f){
                    // ReachDestination();
                }
              transform.forward=positions4[index].position-transform.position;
           
            }
            transform.Translate(Vector3.forward*speed*Time.deltaTime,Space.Self);
           
        }
            if(WaysNum==5){
                      if (index > positions5.Length - 1) return;
            if(Vector3.Distance(positions5[index].position,transform.position)<0.2f){
                if(index!=positions5.Length-1){
                    index++;
                }
                if(Vector3.Distance(positions5[index].position,transform.position)<0.2f){
                    // ReachDestination();
                }
              transform.forward=positions5[index].position-transform.position;
           
            }
            transform.Translate(Vector3.forward*speed*Time.deltaTime,Space.Self);
           
 }   
*/

}
}
